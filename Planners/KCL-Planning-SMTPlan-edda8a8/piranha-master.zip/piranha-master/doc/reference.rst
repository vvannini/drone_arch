.. _reference:

Reference
=========

.. toctree::
   :maxdepth: 2

   concepts.rst
   numerical_types.rst
   symbol_management.rst
   math.rst
   key_interface.rst
   conversions.rst
   kronecker_monomial.rst
