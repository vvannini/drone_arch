.. _conversions:

Conversions
===========

.. toctree::
   :maxdepth: 1

   safe_convert.rst
   safe_cast.rst
