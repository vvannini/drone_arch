.. _key_interface:

Key interface
=============

Comparisons
-----------

.. toctree::
   :maxdepth: 1

   key_key_is_zero.rst
   key_key_is_one.rst

Degree and related
------------------

.. toctree::
   :maxdepth: 1

   key_key_degree.rst
   key_key_ldegree.rst
