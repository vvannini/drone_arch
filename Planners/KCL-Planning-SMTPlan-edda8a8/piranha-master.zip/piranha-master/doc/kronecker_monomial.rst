Kronecker monomial
==================

.. cpp:class:: template <piranha::UncvCppSignedIntegral> piranha::kronecker_monomial
